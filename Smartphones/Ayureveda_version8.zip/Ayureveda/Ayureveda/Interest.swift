import UIKit

class Interest
{
    // MARK: - Public API
    var title = ""
    var featuredImage: UIImage
    var color: UIColor
    
    init(title: String, featuredImage: UIImage, color: UIColor)
    {
        self.title = title
        self.featuredImage = featuredImage
        self.color = color
    }
    
    // MARK: - Private
    // dummy data
    static func fetchInterests() -> [Interest]
    {
        return [
            Interest(title: "aloe", featuredImage: UIImage(named: "aloe.jpg")!, color: UIColor.clear),
            Interest(title: "ashwagandha", featuredImage: UIImage(named: "ashwagandha.jpg")!, color: UIColor.clear),
            Interest(title: "basil", featuredImage: UIImage(named: "basil.jpg")!, color: UIColor.clear),
            Interest(title: "calendula", featuredImage: UIImage(named: "calendula.jpg")!, color: UIColor.clear),
            Interest(title: "eucalyptus", featuredImage: UIImage(named: "eucalyptus.jpg")!, color: UIColor.clear),
            Interest(title: "garlic", featuredImage: UIImage(named: "garlic.jpg")!, color: UIColor.clear),
            Interest(title: "ginger", featuredImage: UIImage(named: "ginger.jpg")!, color: UIColor.clear),
            Interest(title: "hibiscus", featuredImage: UIImage(named: "hibiscus.jpg")!, color: UIColor.clear),
            Interest(title: "liquorice", featuredImage: UIImage(named: "liquorice.jpg")!, color: UIColor.clear),
            Interest(title: "mint", featuredImage: UIImage(named: "mint.jpg")!, color: UIColor.clear),
            Interest(title: "neem", featuredImage: UIImage(named: "neem.jpg")!, color: UIColor.clear),
            Interest(title: "parsley", featuredImage: UIImage(named: "parsley.jpg")!, color: UIColor.clear),
            Interest(title: "rosemary", featuredImage: UIImage(named: "rosemary.jpg")!, color: UIColor.clear),
            Interest(title: "sage", featuredImage: UIImage(named: "sage.jpg")!, color: UIColor.clear),
            Interest(title: "thyme", featuredImage: UIImage(named: "thyme.jpg")!, color: UIColor.clear),
            Interest(title: "turmeric", featuredImage: UIImage(named: "turmeric.jpg")!, color: UIColor.clear)
        ]
    }
}
