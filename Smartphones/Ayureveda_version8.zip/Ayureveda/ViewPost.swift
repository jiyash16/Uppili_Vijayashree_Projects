//
//  ViewPost.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/23/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class ViewPost: UIViewController {

    
    @IBOutlet weak var btnUpdate: UIBarButtonItem!
    @IBOutlet weak var txtProcedure: UITextView!
    @IBOutlet weak var txtBenifits: UITextView!
    @IBOutlet weak var txtDesc: UITextView!
    @IBOutlet weak var txtHerb: UITextField!
    @IBOutlet weak var txtCategory: UITextField!
    @IBOutlet weak var txtPost: UITextField!
    var post : Items!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.populateData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func populateData()
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/posts.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        let itemid = self.post.itemId
        print("itemid to be set\(itemid)")
        let postString = "id=\(itemid)&type=4";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let herbname = (obj["herbname"] as? String)!
                    let categoryname = (obj["categoryname"] as? String)!
                        DispatchQueue.main.async(execute: {
                       
                            self.txtDesc.text = self.post.desc
                            self.txtHerb.text = herbname
                            self.txtPost.text = self.post.itemName
                            self.txtBenifits.text = self.post.benefits
                            self.txtCategory.text = categoryname
                            self.txtProcedure.text = self.post.procedureStep
                            
                        })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    @IBAction func btnUpdateClicked(_ sender: Any) {
        
        let itemname = txtPost.text
        let desc = txtDesc.text
        let proc = txtProcedure.text
        let benifit = txtBenifits.text
        
        if((itemname?.isBlank)! || (desc?.isBlank)! || (proc?.isBlank)! || (benifit?.isBlank)! || !(itemname?.isAlphanumeric)! || !(desc?.isAlphanumeric)! || !(proc?.isAlphanumeric)! || !(benifit?.isAlphanumeric)!)
        {
            let alert = UIAlertController(title: "Error", message: "Enter Alphanumeric data in text fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            self.updatePost(itemname:itemname!, desc:desc!,proc:proc!,benifit:benifit!)
            // print("role to navigate \(role)")
            
            
        }

    }
    func updatePost(itemname:String, desc:String,proc:String,benifit:String)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/posts.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(self.post.itemId)&itemname=\(itemname)&description=\(desc)&benifits=\(benifit)&proc=\(proc)&type=5";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of insert = \(responseString!)")
            //    print("hi insert")
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "Post updated Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                                            }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Post cannot be updated", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addComment"
        {
            let nextScene = segue.destination as? ViewComments
            nextScene?.post = self.post.itemId
            print("post for comment\(post.itemName)")
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
