//
//  Post_admin.swift
//  SidebarMenu
//
//  Created by Vijayashree Uppili on 4/15/17.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit

class Post_admin: UITableViewController
{
    @IBOutlet var postTable: UITableView!
    @IBOutlet weak var menuButton:UIBarButtonItem!
    var postList = [Items]()
    var categoryList = [Category]()
    var herbList = [Herb]()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        self.populateHerbs()
        self.populateCategory()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.populateData();
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func populateData()
    {
        self.postList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/posts.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let itemid = (obj["itemid"] as? String)!
                    let itemname = (obj["itemname"] as? String)!
                     let catid = (obj["subcategoryid"] as? String)!
                     let herbid = (obj["herbid"] as? String)!
                     let description = (obj["description"] as? String)!
                     let benifits = (obj["benifits"] as? String)!
                     let proc = (obj["procedurestep"] as? String)!
                     let postdate = (obj["postdate"] as? String)!
                     let personid = (obj["personid"] as? String)!
                    var post = Items(itemId : Int(itemid)!,itemName : itemname, categoryId : Int(catid)!, herbId : Int(herbid)!, benefits : benifits, procedure : proc, desc : description, postedBy : Int(personid)!, postDate: postdate)
                    self.postList.append(post)
                    print("post = \(itemname)")
                    DispatchQueue.main.async(execute: {
                        self.postTable.reloadData()
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    override func tableView(_ postTable: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postList.count
    }
    
    override func tableView(_ postTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        let item :Items = postList[indexPath.row]
        cell.textLabel?.text = item.itemName
        cell.detailTextLabel?.text = item.desc
        
        return cell
    }
    
    override func tableView(_ postTable: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ postTable: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            // delete data and row
            let item :Items = postList[indexPath.row]
            self.deleteCategory(itemId: item.itemId, indexPath:indexPath,postTable: postTable)
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func deleteCategory(itemId:Int,indexPath : IndexPath,postTable:UITableView)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/posts.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(itemId)&type=3";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of delete = \(responseString!)")
            print("hi delete")
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "Post deleted Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        self.postList.remove(at: indexPath.row)
                        postTable.deleteRows(at: [indexPath], with: .fade)
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Post cannot be deleted", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "detailView", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailView",
            let nextScene = segue.destination as? ViewPost ,
            let indexPath = self.postTable.indexPathForSelectedRow {
            let post = self.postList[indexPath.row]
            nextScene.post = post
            print("post name\(post.itemName)")
        }
        if segue.identifier == "addPost"
        {
            

            let nextScene = segue.destination as? AddPost
             nextScene?.herbList.removeAll()
             nextScene?.herbList   = self.herbList
            nextScene?.categoryList.removeAll()
            nextScene?.categoryList    = self.categoryList
           
        }
    }
    func populateHerbs()
    {
        self.herbList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/herbs.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of delete = \(responseString!)")
            
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let description = (obj["description"] as? String)!
                    let herbname = (obj["herbname"] as? String)!
                    let imagename = (obj["imagename"] as? String)!
                    let scientificname = (obj["scientificname"] as? String)!
                    let herbId = (obj["herbid"] as? String)!
                    var herb = Herb(herbId : Int(herbId)!, herbName : herbname, imageName : imagename, description : description, scientificName : scientificname)
                    self.herbList.append(herb)
                    
                    DispatchQueue.main.async(execute: {
                      
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
        
    }
    func populateCategory()
    {
        self.categoryList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/category.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let catid = (obj["categoryid"] as? String)!
                    let catName = (obj["categoryname"] as? String)!
                    var cat = Category(categoryName: catName, catId :Int(catid)!)
                    self.categoryList.append(cat)
                    print("catName = \(catName)")
                    DispatchQueue.main.async(execute: {
                        
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }


}
