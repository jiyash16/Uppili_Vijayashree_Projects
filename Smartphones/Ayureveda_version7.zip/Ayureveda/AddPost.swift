//
//  AddPost.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/23/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class AddPost: UIViewController, UIPickerViewDelegate{

    @IBOutlet weak var txtPost: UITextField!
   @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var txtBenifit: UITextView!
    @IBOutlet weak var txtProcedure: UITextView!
    @IBOutlet weak var pickerHerb: UIPickerView!
    @IBOutlet weak var pickerCategory: UIPickerView!
    var categoryList = [Category]()
    var herbList = [Herb]()
    override func viewDidLoad() {
        super.viewDidLoad()
     
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        if pickerView.tag == 2 {
            //pickerView1
            return 1
        } else if pickerView.tag == 1{
            return 1
        }
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 2 {
            //pickerView1
            return self.herbList.count
        } else if pickerView.tag == 1{
            return self.categoryList.count
        }
        return 0;
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
      if pickerView.tag == 2 {
            return self.herbList[row].herbName
        } else if pickerView.tag == 1{
            return self.categoryList[row].categoryName
        }
        return "NA"
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
