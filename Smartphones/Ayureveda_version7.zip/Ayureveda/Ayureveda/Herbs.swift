//
//  Herbs.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/7/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class Herbs: UIViewController {

    
    
    @IBOutlet weak var collectionView: UICollectionView!
    var gallery = Gallery.fetchGallery()
    let cellScaling: CGFloat = 0.6
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // self.populateData()
        let screenSize = UIScreen.main.bounds.size
        let cellWidth = floor(screenSize.width * cellScaling)
        let cellHeight = floor(screenSize.height * cellScaling)
        
        let insetX = (view.bounds.width - cellWidth) / 2.0
        let insetY = (view.bounds.height - cellHeight) / 2.0
        
        let layout = collectionView!.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
        collectionView?.contentInset = UIEdgeInsets(top: insetY, left: insetX, bottom: insetY, right: insetX)
        
        collectionView?.dataSource = self
        collectionView?.delegate = self
    }

 func populateData()
{
    var herbList = [Herb]();
    herbList.removeAll()
    let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/herbs.php");
    let request = NSMutableURLRequest(url: myUrl! as URL);
    request.httpMethod = "POST";
    
    let postString = "type=1";
    request.httpBody = postString.data(using: String.Encoding.utf8);
    let task = URLSession.shared.dataTask(with: request as URLRequest) {
        data, response, error in
        
        if error != nil {
            print("error=\(error)")
            return
        }
        let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
        print("****** response data of delete = \(responseString!)")
        
        do {
            
            let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
            for item in json! { // loop through data items
                let obj = item as! NSDictionary
                let description = (obj["description"] as? String)!
                let herbname = (obj["herbname"] as? String)!
                let imagename = (obj["imagename"] as? String)!
                let scientificname = (obj["scientificname"] as? String)!
                let herbId = (obj["herbid"] as? String)!
                var herb = Herb(herbId : Int(herbId)!, herbName : herbname, imageName : imagename, description : description, scientificName : scientificname)
                herbList.append(herb)
                
                DispatchQueue.main.async(execute: {
                    // self.herbTable.reloadData()
                    herbList.forEach { herb in
                    self.gallery.append(Gallery(title: herb.herbName, featuredImage: UIImage(named: herb.imageName)!, color: UIColor.clear))
                        
                    }
            
                    
                })
            }
            
        }catch
        {
            print(error)
        }
    }
    
    task.resume()
    
    
}
}
extension Herbs : UICollectionViewDataSource
{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return gallery.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InterestCell", for: indexPath) as! GalleryCollectionViewCell
        
        cell.gallery = gallery[indexPath.item]
        
        return cell
    }
}

extension Herbs : UIScrollViewDelegate, UICollectionViewDelegate
{
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>)
    {
        let layout = self.collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
        let cellWidthIncludingSpacing = layout.itemSize.width + layout.minimumLineSpacing
        
        var offset = targetContentOffset.pointee
        let index = (offset.x + scrollView.contentInset.left) / cellWidthIncludingSpacing
        let roundedIndex = round(index)
        
        offset = CGPoint(x: roundedIndex * cellWidthIncludingSpacing - scrollView.contentInset.left, y: -scrollView.contentInset.top)
        targetContentOffset.pointee = offset
    }
}
