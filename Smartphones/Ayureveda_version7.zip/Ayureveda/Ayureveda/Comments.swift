//
//  Comments.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation

class Comments
{
    var commentId : Int
    var commentDesc : String
    var itemId : Int
    var commentDate : String
    var personId : Int
    var personName : String
    
    init(commentDesc : String, itemId : Int, personId : Int, commentDate: String,commentId :Int, personName :String)
    {
        self.commentDesc = commentDesc
        self.itemId = itemId
        self.commentDate = commentDate
        self.commentId = commentId
        self.personId = personId
        self.personName = personName
    }
}
