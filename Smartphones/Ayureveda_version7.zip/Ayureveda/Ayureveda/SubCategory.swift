//
//  SubCategory.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation
class SubCateogry
{
    // var subCatId : Int
    var subCatName : String
    var catId : Int
    var items : [(Items)]
    
    init(subCatName : String, catId : Int, items : [(Items)])
    {
        //  self.subCatId = subCatId
        self.subCatName = subCatName
        self.catId = catId
        self.items = items
    }
}
