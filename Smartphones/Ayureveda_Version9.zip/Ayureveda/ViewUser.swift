//
//  ViewUser.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/23/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class ViewUser: UIViewController {
    
    
    @IBOutlet weak var txtAge: UITextField!
    
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtFirstName: UITextField!
    var user : UserAccount!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("userid\(user)")
        // Do any additional setup after loading the view.
        txtUserName.text = user.userName
        self.populateData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func populateData()
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        let userid = self.user.id
        print("userid to be set\(userid)")
        let postString = "uid=\(userid)&type=6";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let firstname = (obj["firstname"] as? String)!
                    let lastname = (obj["lastname"] as? String)!
                    let personid = (obj["personid"] as? String)!
                    let age = (obj["age"] as? String)!
                    let phone = (obj["phone"] as? String)!
                    let email = (obj["email"] as? String)!
                    print("inside call\(firstname)")
                    
                    DispatchQueue.main.async(execute: {
                        self.txtAge.text = age
                        self.txtEmail.text = email
                        self.txtPhone.text = phone
                        self.txtLastName.text = lastname
                        self.txtFirstName.text = firstname
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    @IBAction func btnDelete(_ sender: Any) {
        self.deletePerson()
        
    }
    func deletePerson()
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(user.id)&type=3";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            do {
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        self.deleteUser()
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Person cannot be deleted", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    func deleteUser()
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(user.id)&type=7";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            do {
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "success", message: "User deleted successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        self.txtAge.text = ""
                        self.txtEmail.text = ""
                        self.txtPhone.text = ""
                        self.txtLastName.text = ""
                        self.txtFirstName.text = ""
                        self.txtUserName.text=""
                        
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "User cannot be deleted", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
