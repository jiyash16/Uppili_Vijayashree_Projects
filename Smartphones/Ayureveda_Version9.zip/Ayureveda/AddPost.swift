//
//  AddPost.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/23/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class AddPost: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    
    @IBOutlet weak var txtPost: UITextField!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var txtBenifit: UITextView!
    @IBOutlet weak var txtProcedure: UITextView!
    @IBOutlet weak var pickerHerb: UIPickerView!
    @IBOutlet weak var pickerCategory: UIPickerView!
    var categoryList = [Category]()
    var herbList = [Herb]()
    let defaults = UserDefaults.standard
    var userid : Int = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        txtDescription!.layer.borderWidth = 0.3
        txtDescription!.layer.borderColor = UIColor.lightGray.cgColor
        txtBenifit!.layer.borderWidth = 0.3
        txtBenifit!.layer.borderColor = UIColor.lightGray.cgColor
        txtProcedure!.layer.borderWidth = 0.3
        txtProcedure!.layer.borderColor = UIColor.lightGray.cgColor
        self.pickerCategory.tag = 1
        self.pickerHerb.tag = 2
        print("catcount\(self.categoryList.count) herbcount\(self.herbList.count)")
        // Do any additional setup after loading the view.
        pickerHerb.delegate = self
        pickerCategory.delegate = self
        if let name = defaults.string(forKey: "userid")
        {
            self.userid = Int(name)!
            print("userif\(userid)")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == pickerHerb{
            //pickerView1
            return self.herbList.count
        } else if pickerView == pickerCategory{
            return self.categoryList.count
        }
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView  == pickerHerb{
            return self.herbList[row].herbName
        } else if pickerView == pickerCategory{
            return self.categoryList[row].categoryName
        }
        return "NA"
    }
    
    @IBAction func btnSave(_ sender: Any) {
        var herbid = self.herbList[pickerHerb.selectedRow(inComponent: 0)].herbId
        var categoryid = self.categoryList[pickerCategory.selectedRow(inComponent: 0)].catId
        let post = txtPost.text
        let desc = txtDescription.text
        let benifit = txtBenifit.text
        let proc = txtProcedure.text
        if((post?.isBlank)! || (desc?.isBlank)! || (benifit?.isBlank)! || (proc?.isBlank)! || !(post?.isAlphanumeric)! || !(desc?.isAlphanumeric)! || !(benifit?.isAlphanumeric)! || !(proc?.isAlphanumeric)!)
        {
            let alert = UIAlertController(title: "Error", message: "Enter Alphanumeric data in text fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            self.addPost(herbid: herbid, categoryid :categoryid, post:post!, desc : desc!, benifit: benifit!, proc :proc!)
            // print("role to navigate \(role)")
            
            
        }
        
        
    }
    func addPost(herbid: Int, categoryid :Int, post:String, desc : String, benifit: String, proc :String)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/posts.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        let currentDateTime = Date()
        
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        formatter.dateStyle = .long
        
        // get the date time String from the date
        let now = formatter.string(from: currentDateTime)
        let postString = "herbid=\(herbid)&catid=\(categoryid)&itemname=\(post)&description=\(desc)&benifits=\(benifit)&proc=\(proc)&postdate=\(now)&uid=\(self.userid)&type=2";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            //    print("hi insert")
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "Post added Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        self.txtProcedure.text = ""
                        self.txtBenifit.text = ""
                        self.txtDescription.text = ""
                        self.txtPost.text = ""
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Post cannot be added", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
