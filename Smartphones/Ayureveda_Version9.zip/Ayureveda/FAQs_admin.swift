//
//  FAQs_admin.swift
//  SidebarMenu
//
//  Created by Vijayashree Uppili on 4/15/17.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit

class FAQs_admin: UITableViewController
{
    @IBOutlet weak var menuButton:UIBarButtonItem!
    @IBOutlet var faqTable: UITableView!
    var faqList = [FAQ]();
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    override func viewWillAppear(_ animated: Bool) {
        self.populateData();
    }
    
    func populateData()
    {
        self.faqList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/faqs.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let que = (obj["question"] as? String)!
                    let ans = (obj["answer"] as? String)!
                    let faqId = (obj["faqid"] as? String)!
                    var faq = FAQ(que: que, ans:ans,faqId :Int(faqId)!)
                    self.faqList.append(faq)
                    
                    DispatchQueue.main.async(execute: {
                        self.faqTable.reloadData()
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    override func tableView(_ faqTable: UITableView, numberOfRowsInSection section: Int) -> Int {
        return faqList.count
    }
    
    override func tableView(_ faqTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        let faq :FAQ = faqList[indexPath.row]
        cell.textLabel?.text = faq.question
        cell.textLabel?.numberOfLines = 0;
        cell.textLabel?.textColor = UIColor.blue
        cell.detailTextLabel?.numberOfLines = 0
        cell.detailTextLabel?.text = faq.answer
        
        return cell
    }
    
    override func tableView(_ faqTable: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ faqTable: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            // delete data and row
            let faq :FAQ = faqList[indexPath.row]
            self.deleteCategory(faqId: faq.faqId, indexPath:indexPath,faqTable: faqTable)
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func deleteCategory(faqId:Int,indexPath : IndexPath,faqTable:UITableView)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/faqs.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(faqId)&type=3";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of delete = \(responseString!)")
            // print("hi delete")
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "FAQ deleted Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        self.faqList.remove(at: indexPath.row)
                        faqTable.deleteRows(at: [indexPath], with: .fade)
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "FAQ is associated to post cannot be deleted", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
}
