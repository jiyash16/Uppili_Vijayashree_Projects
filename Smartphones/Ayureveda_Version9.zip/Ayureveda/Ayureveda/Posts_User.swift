//
//  Posts_User.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/20/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class Posts_User: UITableViewController, UISearchResultsUpdating {
    @IBOutlet var postTable: UITableView!
    
    @IBOutlet weak var menuButton:UIBarButtonItem!
    
    var postList = [Items]()
    var filteredTableData = [Items]()
    
    var tableData = [Items]()
        let defaults = UserDefaults.standard
    let searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad()
        
    {
        
        super.viewDidLoad()
        
        
        
        if self.revealViewController() != nil
            
        {
            
            menuButton.target = self.revealViewController()
            
            menuButton.action = "revealToggle:"
            
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        if let name = defaults.string(forKey: "userid")
        {
            print(name)
        }

        
        
              
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.populateData()
        
        self.postTable.reloadData()
        
        searchController.searchResultsUpdater = self
        
        searchController.hidesNavigationBarDuringPresentation = false
        
        searchController.dimsBackgroundDuringPresentation = false
        
        searchController.searchBar.sizeToFit()
        
        
        
        self.postTable.tableHeaderView = searchController.searchBar
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
        
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        
        
        
        let key = searchController.searchBar.text;
        
        if !(key?.isBlank)!
            
        {
            
            self.filteredTableData.removeAll(keepingCapacity: false)
            
            for post in self.postList
                
            {
                
                if post.itemName.containsIgnoringCase(find: key!)
                    
                {
                    
                    self.filteredTableData.append(post)
                    
                }
                
            }
            
            self.tableData = self.filteredTableData
            
        }
            
        else{
            
            self.tableData = self.postList
            
        }
        
        self.postTable.reloadData()
        
    }
    
    
    
    func populateData()
        
    {
        
        self.postList.removeAll()
        
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/posts.php");
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        
        request.httpMethod = "POST";
        
        
        
        let postString = "type=1";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            
            data, response, error in
            
            
            
            if error != nil {
                
                print("error=\(error)")
                
                return
                
            }
            
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            do {
                
                
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                
                for item in json! { // loop through data items
                    
                    let obj = item as! NSDictionary
                    
                    let itemid = (obj["itemid"] as? String)!
                    
                    let itemname = (obj["itemname"] as? String)!
                    
                    let catid = (obj["subcategoryid"] as? String)!
                    
                    let herbid = (obj["herbid"] as? String)!
                    
                    let description = (obj["description"] as? String)!
                    
                    let benifits = (obj["benifits"] as? String)!
                    
                    let proc = (obj["procedurestep"] as? String)!
                    
                    let postdate = (obj["postdate"] as? String)!
                    
                    let personid = (obj["personid"] as? String)!
                    
                    var post = Items(itemId : Int(itemid)!,itemName : itemname, categoryId : Int(catid)!, herbId : Int(herbid)!, benefits : benifits, procedure : proc, desc : description, postedBy : Int(personid)!, postDate: postdate)
                    
                    self.postList.append(post)
                    
                    print("post = \(itemname)")
                    
                    DispatchQueue.main.async(execute: {
                        
                        self.tableData = self.postList
                        
                        self.postTable.reloadData()
                        
                    })
                    
                }
                
                
                
            }catch
                
            {
                
                print(error)
                
            }
            
        }
        
        
        
        task.resume()
        
        
        
    }
    
    override func tableView(_ postTable: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        
        return self.tableData.count
        
        
        
        
        
    }
    
    
    
    override func tableView(_ postTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        
        
        
        
        cell.textLabel?.text = self.tableData[indexPath.row].itemName
        cell.detailTextLabel?.numberOfLines = 0
        cell.detailTextLabel?.text = "posted on:" + self.tableData[indexPath.row].postDate
        cell.imageView?.image = UIImage(named: "user.jpg")!
        
        return cell
        
    }
    
    
    
    
    /*
     
     // MARK: - Navigation
     
     
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     
     // Get the new view controller using segue.destinationViewController.
     
     // Pass the selected object to the new view controller.
     
     }
     
     */
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        performSegue(withIdentifier: "detailView", sender: self)
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "detailView",
            
            let nextScene = segue.destination as? ViewPost_User ,
            
            let indexPath = self.postTable.indexPathForSelectedRow {
            
            let post = self.tableData[indexPath.row]
            
            nextScene.post = post
            
            print("post name\(post.itemName)")
            
        }
        
        
    }
    

}
