//
//  Herbs_User.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/20/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class Herbs_User: UITableViewController {
    @IBOutlet weak var menuButton:UIBarButtonItem!
    @IBOutlet var herbTable: UITableView!
    var herbList = [Herb]();
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    // MARK: - Table view data source
    override func viewWillAppear(_ animated: Bool) {
        self.populateData();
    }
    
    
    func populateData()
    {
        self.herbList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/herbs.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of delete = \(responseString!)")
            
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let description = (obj["description"] as? String)!
                    let herbname = (obj["herbname"] as? String)!
                    let imagename = (obj["imagename"] as? String)!
                    let scientificname = (obj["scientificname"] as? String)!
                    let herbId = (obj["herbid"] as? String)!
                    var herb = Herb(herbId : Int(herbId)!, herbName : herbname, imageName : imagename, description : description, scientificName : scientificname)
                    self.herbList.append(herb)
                    
                    DispatchQueue.main.async(execute: {
                        self.herbTable.reloadData()
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    override func tableView(_ herbTable: UITableView, numberOfRowsInSection section: Int) -> Int {
        return herbList.count
    }
    
    override func tableView(_ herbTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        let herb :Herb = herbList[indexPath.row]
        cell.textLabel?.text = herb.herbName
        cell.detailTextLabel?.text = herb.scientificName
        cell.imageView?.image = UIImage(named: herb.imageName)!
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "detailView", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailView",
            let nextScene = segue.destination as? DisplayHerbs_User ,
            let indexPath = self.herbTable.indexPathForSelectedRow {
            let herb = self.herbList[indexPath.row]
            nextScene.herb = herb
            print("herbname\(herb.herbName)")
        }
        
    }
    

}
