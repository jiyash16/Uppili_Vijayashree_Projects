//
//  FAQs_User.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/20/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class FAQs_User: UITableViewController
{
    @IBOutlet weak var menuButton:UIBarButtonItem!
    @IBOutlet var faqTable: UITableView!
    var faqList = [FAQ]()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool)
    {
        self.populateData();
    }
    
    func populateData()
    {
        self.faqList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/faqs.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest)
        {
            data, response, error in
            
            if error != nil
            {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let que = (obj["question"] as? String)!
                    let ans = (obj["answer"] as? String)!
                    let faqId = (obj["faqid"] as? String)!
                    var faq = FAQ(que: que, ans:ans,faqId :Int(faqId)!)
                    self.faqList.append(faq)
                    
                    DispatchQueue.main.async(execute:
                        {
                            self.faqTable.reloadData()
                    })
                }
                
            }
            catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    override func tableView(_ faqTable: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return faqList.count
    }
    
    override func tableView(_ faqTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        let faq :FAQ = faqList[indexPath.row]
        cell.textLabel?.text = faq.question
        cell.textLabel?.numberOfLines = 0;
        cell.textLabel?.textColor = UIColor.blue
        //cell.imageView?.image = UIImage(named: "q.png")!
        cell.detailTextLabel?.numberOfLines = 0
        cell.detailTextLabel?.text = faq.answer
        
        
        return cell
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
