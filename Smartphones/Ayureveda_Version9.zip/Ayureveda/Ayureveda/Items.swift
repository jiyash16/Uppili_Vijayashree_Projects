//
//  Items.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation
class Items
{
     var itemId : Int
    var itemName : String
    var categoryId : Int
    var desc : String
    var herbId : Int
    var benefits : String
    var procedureStep : String
    var postDate : String
    var uId : Int
    
    init(itemId : Int,itemName : String, categoryId : Int, herbId : Int, benefits : String, procedure : String, desc : String, postedBy : Int, postDate : String)
    {
        self.itemId = itemId
        self.itemName = itemName
        self.categoryId = categoryId
        self.herbId = herbId
        self.benefits = benefits
        self.procedureStep = procedure
        self.desc = desc
        self.uId = postedBy
        self.postDate = postDate
    }
}

