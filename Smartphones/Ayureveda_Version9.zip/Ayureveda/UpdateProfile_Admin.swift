//

//  UpdateProfile_Admin.swift

//  SidebarMenu

//

//  Created by Vijayashree Uppili on 4/15/17.

//  Copyright © 2017 AppCoda. All rights reserved.

//



import UIKit



class UpdateProfile_Admin: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var menuButton:UIBarButtonItem!
    
    @IBOutlet weak var txtAge: UITextField!
    
    
    
    
    
    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var imgUser: UIImageView!
    
    let defaults = UserDefaults.standard
    
    var userid : Int = 0
    
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        picker.delegate = self
        
        
        if self.revealViewController() != nil
            
        {
            
            menuButton.target = self.revealViewController()
            
            
            
            menuButton.action = "revealToggle:"
            
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
            if let name = defaults.string(forKey: "userid")
                
            {
                
                self.userid = Int(name)!
                
                print("userif\(userid)")
                
            }
            
        }
        
        
        
        // Do any additional setup after loading the view.
        
        self.populateData()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        
        
        
        // Dispose of any resources that can be recreated.
        
    }
    
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               
                               didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        
        imgUser.contentMode = .scaleAspectFit //3
        
        imgUser.image = chosenImage //4
        
        dismiss(animated:true, completion: nil) //5
        
    }
    
    @IBAction func addPhoto(_ sender: Any) {
        
        picker.allowsEditing = false
        
        picker.sourceType = .photoLibrary
        
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        
        present(picker, animated: true, completion: nil)
        
    }
    
    
    
    func populateData()
        
    {
        
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        
        request.httpMethod = "POST";
        
        let userid = self.userid
        
        print("userid to be set\(userid)")
        
        let postString = "uid=\(userid)&type=6";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            
            data, response, error in
            
            
            
            if error != nil {
                
                print("error=\(error)")
                
                return
                
            }
            
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            
            
            do {
                
                
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                
                for item in json! { // loop through data items
                    
                    let obj = item as! NSDictionary
                    
                    let firstname = (obj["firstname"] as? String)!
                    
                    let lastname = (obj["lastname"] as? String)!
                    
                    let personid = (obj["personid"] as? String)!
                    
                    let age = (obj["age"] as? String)!
                    
                    let phone = (obj["phone"] as? String)!
                    
                    let email = (obj["email"] as? String)!
                    
                    print("inside call\(firstname)")
                    
                    
                    
                    DispatchQueue.main.async(execute: {
                        
                        
                        
                        self.txtEmail.text = email
                        
                        self.txtPhone.text = phone
                        
                        self.txtLastName.text = lastname
                        
                        self.txtFirstName.text = firstname
                        
                    })
                    
                }
                
                
                
            }catch
                
            {
                
                print(error)
                
            }
            
        }
        
        
        
        task.resume()
        
        
        
    }
    
    @IBAction func btnUpdate(_ sender: Any) {
        
        let lastName = txtLastName.text
        
        let phone = txtPhone.text
        
        let firstName = txtFirstName.text
        
        if((firstName?.isBlank)! || (lastName?.isBlank)! )
            
        {
            
            let alert = UIAlertController(title: "Error", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            
            return
            
        }
        
        if(!(firstName?.isAlphanumeric)! || !(lastName?.isAlphanumeric)!)
            
        {
            
            let alert = UIAlertController(title: "Error", message: "Firstname, Lastname should be alphanumeric", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            
            return;
            
            
            
        }
        
        
        
        self.updateUser(firstname:firstName!,lastname:lastName!)
        
        
        
        
        
    }
    
    func updateUser(firstname:String, lastname:String)
        
    {
        
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        
        
        
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        
        request.httpMethod = "POST";
        
        
        
        let postString = "id=\(self.userid)&firstname=\(firstname)&lastname=\(lastname)&type=8";
        
        
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            
            data, response, error in
            
            
            
            if error != nil {
                
                print("error=\(error)")
                
                return
                
            }
            
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            
            
            do {
                
                DispatchQueue.main.async(execute: {
                    
                    if responseString == "success"
                        
                    {
                        
                        let alert = UIAlertController(title: "success", message: "Profile updated successfully", preferredStyle: UIAlertControllerStyle.alert)
                        
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        
                        self.present(alert, animated: true, completion: nil)
                        
                        
                        
                        
                        
                    }
                        
                    else{
                        
                        let alert = UIAlertController(title: "Error", message: "Profile cannot be updated", preferredStyle: UIAlertControllerStyle.alert)
                        
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        
                        self.present(alert, animated: true, completion: nil)
                        
                    }
                    
                    
                    
                })
                
            }catch
                
            {
                
                print(error)
                
            }
            
            
            
        }
        
        
        
        task.resume()
        
    }
    
    /*
     
     // MARK: - Navigation
     
     
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     
     // Get the new view controller using segue.destinationViewController.
     
     // Pass the selected object to the new view controller.
     
     }
     
     */
    
    
    
}
