//
//  AddComment.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/24/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class ViewComments: UITableViewController {
    
    @IBOutlet var commentTable: UITableView!
    var post : Int!
    var commetList = [Comments]()
    let defaults = UserDefaults.standard
    var uid : Int = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        print("post sent\(self.post)")
        if let name = defaults.string(forKey: "userid")
        {
            self.uid = Int(name)!
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.populateData();
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func populateData()
    {
        self.commetList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/comments.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(self.post!)&type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let itemid = (obj["itemid"] as? String)!
                    let commentid = (obj["commentid"] as? String)!
                    let commentdate = (obj["commentdate"] as? String)!
                    let description = (obj["description"] as? String)!
                    let personid = (obj["personid"] as? String)!
                    let personFirstname = (obj["firstname"] as? String)!
                    let personLastname = (obj["lastname"] as? String)!
                    let personName = "\(personFirstname) \(personLastname)"
                    print("personmane \(personName)")
                    var comment = Comments(commentDesc : description, itemId : Int(itemid)!, personId : Int(personid)!, commentDate: commentdate,commentId :Int(commentid)!, personName: personName)
                    self.commetList.append(comment)
                    DispatchQueue.main.async(execute: {
                        self.commentTable.reloadData()
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    override func tableView(_ commentTable: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.commetList.count
    }
    
    override func tableView(_ commentTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        let comment :Comments = self.commetList[indexPath.row]
        cell.textLabel?.text = comment.personName
        cell.detailTextLabel?.numberOfLines = 0
        cell.detailTextLabel?.text = "posted on:" + comment.commentDate + "\n"+comment.commentDesc
        
        return cell
    }
    
    override func tableView(_ commentTable: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ commentTable: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            // delete data and row
            let comment :Comments = self.commetList[indexPath.row]
            self.deleteComment(commentId: comment.commentId, indexPath:indexPath,commentTable: commentTable)
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func deleteComment(commentId:Int,indexPath : IndexPath,commentTable:UITableView)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/comments.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(commentId)&type=3";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "Comment deleted Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        self.commetList.remove(at: indexPath.row)
                        commentTable.deleteRows(at: [indexPath], with: .fade)
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Comment cannot be deleted", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    @IBAction func btnReply(_ sender: Any) {
        self.askForComment()
    }
    func askForComment() {
        let alertController = UIAlertController(title: "Commets", message: "Please enter a Comment:", preferredStyle: UIAlertControllerStyle.alert)
        
        alertController.addTextField(configurationHandler: nil)
        
        let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (action) -> Void in
            let textfield = alertController.textFields![0]
            if textfield.text?.characters.count == 0 {
                // self.askForNickname()
            }
            else {
                //  self.nickname = textfield.text
                let commentdesc = textfield.text
                print("comment added \(textfield.text)")
                self.saveComment(commentdesc:commentdesc!)
                
            }
        }
        
        alertController.addAction(OKAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func saveComment(commentdesc:String)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/comments.php");
        let currentDateTime = Date()
        
        // initialize the date formatter and set the style
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        formatter.dateStyle = .long
        
        // get the date time String from the date
        let now = formatter.string(from: currentDateTime)
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "itemid=\(post!)&description=\(commentdesc)&commentdate=\(now)&uid=\(self.uid)&type=2";
        print("poststring\(postString)")
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            //    print("hi insert")
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        self.populateData()
                        let alert = UIAlertController(title: "Success", message: "Comment posted Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Comment cannot be added", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
