//
//  MapViewController.swift
//  SidebarMenu
//
//  Created by Simon Ng on 2/2/15.
//  Copyright (c) 2015 AppCoda. All rights reserved.
//

import UIKit

class CategoryController: UITableViewController {
    
    @IBOutlet weak var menuButton: UIBarButtonItem!
    var categoryList = [Category]();
    
    @IBOutlet var catTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        // Do any additional setup after loading the view.
        //  var cat = Category(categoryName: "cats")
        //self.categoryList.append(cat)
        // print(self.categoryList.count)
        //self.populateData();
        // print("category retirved\(self.categoryList.count)")
    }
    override func viewWillAppear(_ animated: Bool) {
        self.populateData();
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func populateData()
    {
        self.categoryList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/category.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let catid = (obj["categoryid"] as? String)!
                    let catName = (obj["categoryname"] as? String)!
                    var cat = Category(categoryName: catName, catId :Int(catid)!)
                    self.categoryList.append(cat)
                    print("catName = \(catName)")
                    DispatchQueue.main.async(execute: {
                        self.catTable.reloadData()
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    override func tableView(_ catTable: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categoryList.count
    }
    
    override func tableView(_ catTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        let cat :Category = categoryList[indexPath.row]
        cell.textLabel?.text = cat.categoryName
        
        return cell
    }
    
    override func tableView(_ catTable: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ catTable: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            // delete data and row
            let cat :Category = categoryList[indexPath.row]
            self.deleteCategory(catId: cat.catId, indexPath:indexPath,catTable: catTable)
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func deleteCategory(catId:Int,indexPath : IndexPath,catTable:UITableView)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/category.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "id=\(catId)&type=3";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of delete = \(responseString!)")
            print("hi delete")
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "Category deleted Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        self.categoryList.remove(at: indexPath.row)
                        catTable.deleteRows(at: [indexPath], with: .fade)
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Category is associated to post cannot be deleted", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
}
