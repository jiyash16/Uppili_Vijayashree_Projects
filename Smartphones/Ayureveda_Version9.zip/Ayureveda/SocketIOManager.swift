//
//  SocketIOManager.swift
//  SocketChat
//
//  Created by Vijayashree Uppili on 4/14/17.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit

class SocketIOManager: NSObject {
static let sharedInstance = SocketIOManager()
    
    override init() {
        super.init()
    }
    var socket: SocketIOClient = SocketIOClient(socketURL: NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com:3000")! as URL)
    
    func establishConnection() {
        socket.connect()
    }
    
    
    func closeConnection() {
        socket.disconnect()
    }
    
    func connectToServerWithNickname(nickname: String, completionHandler: @escaping (_ userList: [[String: AnyObject]]) -> Void) {
        socket.emit("connectUser", nickname)
        socket.on("userList") { ( dataArray, ack) -> Void in
            completionHandler(dataArray[0] as! [[String: AnyObject]])
        }
    }
    func exitChatWithNickname(nickname: String, completionHandler: () -> Void) {
        socket.emit("exitUser", nickname)
        completionHandler()
    }
    func sendMessage(message: String, withNickname nickname: String) {
        socket.emit("chatMessage", nickname, message)
    }
    func getChatMessage(completionHandler: @escaping ([String: AnyObject]) -> Void) {
        socket.on("newChatMessage") { (dataArray, socketAck) -> Void in
            var messageDictionary = [String: AnyObject]()
            messageDictionary["nickname"] = dataArray[0] as! String as AnyObject
            messageDictionary["message"] = dataArray[1] as! String as AnyObject
            messageDictionary["date"] = dataArray[2] as! String as AnyObject
            
            completionHandler(messageDictionary)
        }
    }
}
