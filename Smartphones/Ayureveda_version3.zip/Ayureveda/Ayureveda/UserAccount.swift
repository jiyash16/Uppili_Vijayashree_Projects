//
//  UserAccount.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation
class UserAccount
{
   // var id : Int
    var userName : String
    var password : String
    var role : String
  //  var status : String = "Active"
  //  var person : Person
   
    init(userName : String, password : String, role : String)
    {
        self.userName = userName
        self.password = password
        self.role = role
    
    }
 
}
