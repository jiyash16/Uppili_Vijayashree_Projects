//
//  Comments.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation

class Comments
{
   // var commentId : Int
    var commentDesc : String
  //  var itemId : Int
    var item : Items
  //  var commentDate : Date
  //  var personId : Int
    var person : Person
    
    init(commentDesc : String, item : Items, person : Person)
    {
        self.commentDesc = commentDesc
        self.item = item
        self.person = person
    //  self.commentDate = Date
    }
}
