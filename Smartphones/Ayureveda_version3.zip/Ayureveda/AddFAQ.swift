//
//  AddFAQ.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/20/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class AddFAQ: UIViewController {
    @IBOutlet weak var txtResponse: UITextView!
    @IBOutlet weak var txtQuestion: UITextField!
   
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func addFaq(_ sender: Any) {
        let question = txtQuestion.text;
        let response = txtResponse.text;
        
        if((question?.isBlank)! || (response?.isBlank)! || (question?.isAlphanumeric)! || (response?.isAlphanumeric)!)
        {
            let alert = UIAlertController(title: "Error", message: "Enter Alphanumeric data in text fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            self.addFAQ(question:question!, response:response!)
            // print("role to navigate \(role)")
            
            
        }

    }
    func addFAQ(question:String, response:String)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/faqs.php");
        
        
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "question="+question+"&response="+response+"&type=2";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of insert = \(responseString!)")
        //    print("hi insert")
            //  let data = responseString?.data(using: String.Encoding.utf8.rawValue)!
            do {
                
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "FAQ Added Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        self.txtQuestion.text = ""
                        self.txtResponse.text=""
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Question should be unique", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }

}
