//
//  DisplayHerb.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/21/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class DisplayHerb: UIViewController {

    @IBOutlet weak var lblHerb: UILabel!
    var herb:Herb!
    @IBOutlet weak var txtHerbDesc: UITextView!
    @IBOutlet weak var imgHerb: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtHerbDesc.text = herb.description;
        lblHerb.text = herb.herbName+"("+herb.scientificName + ")"
        // Do any additional setup after loading the view.
        print("inside disply\(herb.herbName)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
