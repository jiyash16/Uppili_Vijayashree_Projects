//
//  SignUp.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/7/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class SignUp: UIViewController {

    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtFirstName: UITextField!
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btnSignUp(_ sender: Any) {
        let firstName = txtFirstName.text
        let lastName = txtLastName.text
        let phone = txtPhone.text
        let age = txtAge.text
        let email = txtEmail.text
        let username = txtUserName.text
        let password = txtPassword.text
        
        if((firstName?.isBlank)! || (lastName?.isBlank)!  || (phone?.isBlank)!  || (email?.isBlank)!  || (age?.isBlank)!  || (username?.isBlank)!  || (password?.isBlank)! )
        {
            let alert = UIAlertController(title: "Error", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            if(!(firstName?.isAlphanumeric)! || !(lastName?.isAlphanumeric)! || !(username?.isAlphanumeric)!)
            {
                let alert = UIAlertController(title: "Error", message: "Firstname, Lastname, username should be alphanumeric", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;

            }
            if(!(phone?.isPhone)!)
            {
                let alert = UIAlertController(title: "Error", message: "Phone number should be in format xxx-xxx-xxxx ", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;
            }
            if( !(age?.isNumber)!)
            {
                let alert = UIAlertController(title: "Error", message: "Invalid age", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;
            }
           if(!(email?.isValidEmail)!)
            {
                let alert = UIAlertController(title: "Error", message: "Invalid email id", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;
            }
 
            
            self.addUser(firstName : firstName!, lastName :lastName! , phone:phone!, age:age! , email:email!, username:username!, password:password!)
            // print("role to navigate \(role)")
            
            
        }
        
    }
    func addUser(firstName : String, lastName :String , phone:String, age:String , email:String, username:String, password:String)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        let pass = password.base64Encoded()
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "username="+username+"&password="+pass!+"&type=2";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            //  print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("****** response data of insert = \(responseString!)")
            do {
                
                DispatchQueue.main.async(execute: {
                    if responseString == "error"
                    {
                        let alert = UIAlertController(title: "Error", message: "username should be unique", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)

                    }
                    else{
                        let id = Int(responseString! as String)
                        self.addPerson(firstName : firstName, lastName :lastName , phone:phone, age:age , email:email,uid:id!)
                    }
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }

    func addPerson(firstName : String, lastName :String , phone:String, age:String , email:String, uid: Int)
    {
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString1 = "firstname="+firstName+"&lastname="+lastName
        let postString2 = "&uid=\(uid)&phone="+phone
        let postString3 = "&email="+email+"&type=4"
        let postString4 = "&age="+age

        let postString = postString1 + postString2+postString3+postString4
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            //  print("******* response = \(response)")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                do {
                
                DispatchQueue.main.async(execute: {
                    if responseString == "success"
                    {
                        let alert = UIAlertController(title: "Success", message: "User Added successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                     
                        
                        
                    }
                    else{
                        let alert = UIAlertController(title: "Error", message: "Error Adding user", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    self.txtPassword.text = ""
                    self.txtUserName.text = ""
                    self.txtPhone.text = ""
                    self.txtAge.text = ""
                    self.txtEmail.text = ""
                    self.txtFirstName.text = ""
                    self.txtLastName.text = ""
                })
            }catch
            {
                print(error)
            }
            
        }
        
        task.resume()
        
    }

}
