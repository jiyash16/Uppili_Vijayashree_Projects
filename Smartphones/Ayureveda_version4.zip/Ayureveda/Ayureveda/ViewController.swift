//
//  ViewController.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/7/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var webViewBG: UIWebView!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var RememberMe: UISwitch!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var marqee: UILabel!
     var result : String = ""
    var status : String = ""
    var uid:String = ""
       let defaults = UserDefaults.standard
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // background GIF code
        
        let htmlPath = Bundle.main.path(forResource: "WebViewContent", ofType: "html")
        let htmlURL = URL(fileURLWithPath: htmlPath!)
        let html = try? Data(contentsOf: htmlURL)
        
        self.webViewBG.load(html!, mimeType: "text/html", textEncodingName: "UTF-8", baseURL: htmlURL.deletingLastPathComponent())
        // Do any additional setup after loading the view, typically from a nib.
        
        //marquee function
//        UIView.animate(withDuration: 12.0, delay: 1, options: ([.curveLinear, .repeat]), animations: {() -> Void in
//            self.marqee.center = CGPoint(0 - self.marqee.bounds.size.width / 2, self.marqee.center.y)
//        }, completion:  { _ in })
        
        UIView.animate(withDuration: 12.0, delay: 1, options: ([.curveLinear, .repeat]), animations: {() -> Void in
            self.marqee.center = CGPoint(x: 0 - self.marqee.bounds.size.width, y: self.marqee.center.y)
        }, completion:  { _ in })
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // Login button action
    
    @IBAction func loginClicked(_ sender: Any)
    {
        let username = txtUserName.text;
        let password = txtPassword.text;
        
        if((username?.isBlank)! || (password?.isBlank)!)
        {
            let alert = UIAlertController(title: "Error", message: "Enter data in Text fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            authenticateUser(uname:username!, pass:password!)
           // print("role to navigate \(role)")
           
            
        }
    }
    
    func authenticateUser(uname:String, pass:String)
    {
    // Do any additional setup after loading the view, typ:wq!ically from a nib.
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        let encodePass = pass.base64Encoded();
   //     print("encoded pass\(encodePass)")
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
    
        let postString = "username="+uname+"&password="+encodePass!+"&type=1";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
    
            if error != nil {
                print("error=\(error)")
                return
            }
   // print("******* response = \(response)")
    
    // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
  //  print("****** response data = \(responseString!)")
            do {
    
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let role = (obj["role"] as? String)!
                    let status = (obj["status"] as? String)!
                    let uid = (obj["id"] as? String)!
                    self.status = status
                    self.result = role
                    self.uid = uid
                    print("role = \(role)")
                    break;
                    }
                DispatchQueue.main.async(execute: {
                    if self.status == "ACTIVE"
                    {
                        self.defaults.set(self.uid, forKey: "userid")
                        if self.result == "admin"
                        {
                         //   print("inside if")
                         
                            
                            self.performSegue(withIdentifier: "adminPage", sender: self)
                        }
                        else if self.result == "user"
                        {
                            self.performSegue(withIdentifier: "userPage", sender: self)
                        }
                    }
                    else
                    {
                        let alert = UIAlertController(title: "Error", message: "Invalid credentials", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)

                    }
                })
            }catch
            {
                print(error)
            }
        }
    
        task.resume()
           }
    
    
   

    }

