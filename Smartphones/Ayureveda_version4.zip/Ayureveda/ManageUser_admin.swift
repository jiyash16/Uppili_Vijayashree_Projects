//
//  ManageUser_admin.swift
//  SidebarMenu
//
//  Created by Vijayashree Uppili on 4/15/17.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit

class ManageUser_admin: UITableViewController
{
    @IBOutlet var userTable: UITableView!
@IBOutlet weak var menuButton:UIBarButtonItem!
    var userList = [UserAccount]();
    override func viewDidLoad() {
        super.viewDidLoad()

        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        self.populateData();
    }
    
    
    func populateData()
    {
        self.userList.removeAll()
        let myUrl = NSURL(string: "http://ec2-54-71-116-148.us-west-2.compute.amazonaws.com/Ayurveda/useraccount.php");
        let request = NSMutableURLRequest(url: myUrl! as URL);
        request.httpMethod = "POST";
        
        let postString = "type=5";
        request.httpBody = postString.data(using: String.Encoding.utf8);
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSArray
                for item in json! { // loop through data items
                    let obj = item as! NSDictionary
                    let username = (obj["username"] as? String)!
                    let password = (obj["password"] as? String)!
                    let role = (obj["role"] as? String)!
                    let status = (obj["status"] as? String)!
                    let id = (obj["id"] as? String)!
                    var user = UserAccount(userName:username, password:password , role: role, id : Int(id)!, status : status)
                    self.userList.append(user)
                    
                    DispatchQueue.main.async(execute: {
                        self.userTable.reloadData()
                    })
                }
                
            }catch
            {
                print(error)
            }
        }
        
        task.resume()
        
    }
    override func tableView(_ userTable: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userList.count
    }
    
    override func tableView(_ userTable: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        let user :UserAccount = userList[indexPath.row]
        cell.textLabel?.text = "\(user.userName)(\(user.role))"
        cell.detailTextLabel?.text = user.status
        
        return cell
    }
    
  
    override func tableView(_ userTable: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "detailView", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailView",
            let nextScene = segue.destination as? ViewUser ,
            let indexPath = self.userTable.indexPathForSelectedRow {
            let user = self.userList[indexPath.row]
            nextScene.user = user
            print("uid\(user)")
        }
        
    }

}
