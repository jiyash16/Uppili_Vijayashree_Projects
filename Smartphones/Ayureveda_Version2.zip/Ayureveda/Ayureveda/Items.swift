//
//  Items.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation
class Items
{
   // var itemId : Int
    var itemName : String
  //  var subCatId : Int
    var subCat : SubCateogry
    var description : String
   // var herbId : Int
    var herbs : Herbs
    var benefits : String
    var procedureStep : String
  //  var comments : [(Comments)]
//    var like : [(Like)]
  //  var postDate : Date
    var personId : Int
   
    init(itemName : String, sub : SubCateogry, herb : Herbs, benefits : String, procedure : String, desc : String, postedBy : Int)
    {
        self.itemName = itemName
        self.subCat = sub
        self.herbs = herb
        self.benefits = benefits
        self.procedureStep = procedure
        self.description = desc
        self.personId = postedBy
        
    }
}
