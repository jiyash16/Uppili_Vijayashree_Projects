//
//  SpeechViewController.h
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/16/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpeechViewController : UIViewController
@property NSString *response;
@end
