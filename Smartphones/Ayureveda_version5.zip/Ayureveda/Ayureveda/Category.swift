//
//  Category.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation

class Category
{
    var catId : Int
    var categoryName : String
    
    
    init(categoryName : String, catId : Int)
    {
        self.catId = catId
        self.categoryName = categoryName
        //    self.subCategory = subCategory
    }
    
}
