import UIKit

class Interest
{
    // MARK: - Public API
    var title = ""
    var featuredImage: UIImage
    var color: UIColor
    
    init(title: String, featuredImage: UIImage, color: UIColor)
    {
        self.title = title
        self.featuredImage = featuredImage
        self.color = color
    }
    
    // MARK: - Private
    // dummy data
    static func fetchInterests() -> [Interest]
    {
        return [
            Interest(title: "aloe", featuredImage: UIImage(named: "aloe")!, color: UIColor.clear),
            Interest(title: "ashwagandha", featuredImage: UIImage(named: "ashwagandha")!, color: UIColor.clear),
            Interest(title: "basil", featuredImage: UIImage(named: "basil")!, color: UIColor.clear),
            Interest(title: "calendula", featuredImage: UIImage(named: "calendula")!, color: UIColor.clear),
            Interest(title: "eucalyptus", featuredImage: UIImage(named: "eucalyptus")!, color: UIColor.clear),
            Interest(title: "garlic", featuredImage: UIImage(named: "garlic")!, color: UIColor.clear),
            Interest(title: "ginger", featuredImage: UIImage(named: "ginger")!, color: UIColor.clear),
            Interest(title: "hibiscus", featuredImage: UIImage(named: "hibiscus")!, color: UIColor.clear),
            Interest(title: "liquorice", featuredImage: UIImage(named: "liquorice")!, color: UIColor.clear),
            Interest(title: "mint", featuredImage: UIImage(named: "mint")!, color: UIColor.clear),
            Interest(title: "neem", featuredImage: UIImage(named: "neem")!, color: UIColor.clear),
            Interest(title: "parsley", featuredImage: UIImage(named: "parsley")!, color: UIColor.clear),
            Interest(title: "rosemary", featuredImage: UIImage(named: "rosemary")!, color: UIColor.clear),
            Interest(title: "sage", featuredImage: UIImage(named: "sage")!, color: UIColor.clear),
            Interest(title: "thyme", featuredImage: UIImage(named: "thyme")!, color: UIColor.clear),
            Interest(title: "turmeric", featuredImage: UIImage(named: "turmeric")!, color: UIColor.clear)
        ]
    }
}
