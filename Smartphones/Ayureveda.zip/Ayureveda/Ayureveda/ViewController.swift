//
//  ViewController.swift
//  Ayureveda
//
//  Created by Vijayashree Uppili on 4/7/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var webViewBG: UIWebView!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var RememberMe: UISwitch!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var marqee: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // background GIF code
        
        let htmlPath = Bundle.main.path(forResource: "WebViewContent", ofType: "html")
        let htmlURL = URL(fileURLWithPath: htmlPath!)
        let html = try? Data(contentsOf: htmlURL)
        
        self.webViewBG.load(html!, mimeType: "text/html", textEncodingName: "UTF-8", baseURL: htmlURL.deletingLastPathComponent())
        // Do any additional setup after loading the view, typically from a nib.
        
        //marquee function
//        UIView.animate(withDuration: 12.0, delay: 1, options: ([.curveLinear, .repeat]), animations: {() -> Void in
//            self.marqee.center = CGPoint(0 - self.marqee.bounds.size.width / 2, self.marqee.center.y)
//        }, completion:  { _ in })
        
        UIView.animate(withDuration: 12.0, delay: 1, options: ([.curveLinear, .repeat]), animations: {() -> Void in
            self.marqee.center = CGPoint(x: 0 - self.marqee.bounds.size.width, y: self.marqee.center.y)
        }, completion:  { _ in })
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // Login button action
    
    @IBAction func loginClicked(_ sender: Any)
    {
    }


}

