//
//  FAQ.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation
class FAQ
{
    var faqId : Int
    var question : String
    var answer : String
    
    init(que : String, ans : String, faqId :Int)
    {
        self.faqId = faqId
        self.question = que
        self.answer = ans
    }
}
