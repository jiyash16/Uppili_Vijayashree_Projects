//
//  Person.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation
class Person
{
    // var personId : Int
    //  var userAccount : UserAccount
    var firstName : String
    var lastName : String
    var age : Int
    var phone : String
    var email : String
    // var comments : [(Comments)]
    
    init(fName : String, lName : String, email : String, age : Int, phone : String)
    {
        self.firstName = fName
        self.lastName = lName
        self.email = email
        self.age = age
        self.phone = phone
    }
}

