//
//  Herbs.swift
//  Base64
//
//  Created by Vijayashree Uppili on 4/17/17.
//  Copyright © 2017 Vijayashree Uppili. All rights reserved.
//

import Foundation
class Herb
{
    var herbId : Int
    var herbName : String
    var imageName : String
    var description : String
    var scientificName : String
    init(herbId : Int, herbName : String, imageName : String, description : String, scientificName : String)
    {
        self.herbId = herbId
        self.herbName = herbName
        self.imageName = imageName
        self.description = description
        self.scientificName = scientificName
    }
}
